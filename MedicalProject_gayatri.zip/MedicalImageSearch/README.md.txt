# A Fast Nearest Neighbor Search Scheme over Outsourced Encrypted Medical Images
![Java](https://img.shields.io/badge/Java-17%2B-blue)
![License](https://img.shields.io/badge/License-MIT-green)
![MySQL](https://img.shields.io/badge/Database-MySQL-orange)

A secure Java-based system for performing *exact nearest neighbor searches* over encrypted medical images stored in a cloud database. This project ensures data privacy through AES encryption and uses JDBC for efficient database operations.
-Patient registration/login system
-Medical image encryption/decryption
-Opencv-based image processing
-Nearest neighbour search over encrypted data
---

## 📌 Features
- *AES-128 Encryption/Decryption*: Secure encryption of medical images before outsourcing.
- *Exact Nearest Neighbor Search*: Uses mean and standard deviation to compute lower bounds of Euclidean distance for fast candidate rejection.
- *JDBC Database Integration*: Store encrypted images and metadata (mean, standard deviation) in a MySQL database.
- *Modular Codebase*: Separates encryption, database operations, and search logic for maintainability.
---
## Authentication Module
- User registration with:
  - Username/password
  - Personal details (name, address, phone)
  - 4-digit security PIN
- Secure login system
- Data persistence using properties files

### Image Processing Module
- Image upload and encryption (AES-128)
- OpenCV operations:
  - Grayscale conversion
  - Resizing
  - Feature extraction
- Nearest neighbor search using lower-bound Euclidean distance

## 🛠 Technologies Used
- *Java 16*
- *open cv*
- *JDBC* (MySQL Connector/J 8.0+)
- *AES Encryption*
- *MySQL Database*

---
## ⚙ Installation

### Prerequisites
- Java 16 JDK
- MySQL Server
- MySQL Connector/J(JDBC Driver)

2. *Configure the Database*:
   - Start MySQL and create a database:
     sql
     CREATE DATABASE medical_Db;
     
   - Update database credentials in src/main/java/DatabaseConnection.java:
     java
     private static final String URL = "jdbc:mysql://localhost:3306/medical_images";
     private static final String USER = "your_mysql_username";
     private static final String PASSWORD = "your_mysql_password";

---
3. *Add JDBC Driver*:
   - Download mysql-connector-java-8.0.30.jar (or latest version).
   - Place the JAR file in your project’s lib folder.
   - Add it to your classpath when compiling/running:
     bash
     javac -cp ".;lib/mysql-connector-java-8.0.30.jar" src/*.java
     java -cp ".;lib/mysql-connector-java-8.0.30.jar" MainClass
     

---
## 🗄 Database Setup
Run this SQL script in your MySQL database to create the images table:
sql
CREATE TABLE mimic_cxr_images(
id VARCHAR(50) PRIMARY KEY,
patient_id VARCHAR(50) NOT NULL,
study_id VARCHAR(50) NOT NULL,
image_path VARCHAR(255) NOT NULL,
text TEXT,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
SELECT * FROM mimic_cxr_images WHERE id = '1000116691';
SELECT * FROM mimic_cxr_images;
DESCRIBE mimic_cxr_images;
SELECT id, encrypted_data FROM mimic_cxr_images WHERE encrypted_data IS NULL;
ALTER TABLE mimic_cxr_images
ADD COLUMN encrypted_data BLOB;
---

## 🔒 Encryption Details
*AES-128* is used for encrypting image data. Example code:
java
// Generate a key
SecretKey key = AESEncryption.generateKey();

// Encrypt image bytes
String encryptedData = AESEncryption.encrypt(imageBytes, key);

// Decrypt image bytes
byte[] decryptedBytes = AESEncryption.decrypt(encryptedData, key);
---

## 🔍 Nearest Neighbor Search
The algorithm rejects non-candidates early using the lower bound of Euclidean distance:
java
public static int findNearestNeighbor(double[][] encryptedImages, double[] query, double mean, double stdDev) {
    // Iterate through candidates and compute lower bound
    double lowerBound = computeLowerBound(query, candidate, mean, stdDev);
    if (lowerBound < minDistance) {
        // Update nearest neighbor
    }
}


---


## 🚀 Usage Example

### 1. Insert an Encrypted Image
java
public static void main(String[] args) throws Exception {
    // Load image bytes
    byte[] imageBytes = Files.readAllBytes(Paths.get("path/to/image.png"));
    
    // Generate AES key and encrypt
    SecretKey key = AESEncryption.generateKey();
    String encryptedData = AESEncryption.encrypt(imageBytes, key);
    
    // Insert into database
    InsertImage.insert(encryptedData.getBytes(), 0.5, 0.1); // mean=0.5, stdDev=0.1
}


### 2. Search for Nearest Neighbor
java
public static void main(String[] args) {
    double[] query = {0.6,0.7}; // Example query vector
    int nearestIndex = NearestNeighborSearch.findNearestNeighbor(encryptedImages, query, 0.5, 0.1);
    System.out.println("Nearest Neighbor Index: " + nearestIndex);
}

*Start Application*
   bash
   javac -cp ".:lib/*" src/*.java
   java -cp ".:lib/*" -Djava.library.path=/path/to/opencv/lib MedicalSystem
   

2. *Registration*
   - Fill in all fields in registration form
   - Password must be ≥8 characters
   - Phone number must be 10 digits
   - PIN must be 4 digits

3. *Login*
   - Use registered credentials
   - Successful login grants access to image processing features

4. *Image Processing*
   - Upload medical images (JPG/PNG)
   - View processing results:
     - Original image
     - Grayscale conversion
     - Resized image
   - Encrypt/decrypt images

---
# ⚙ Configuration

1. *Database Connection*  
   Edit config/db.properties:
   properties
   db.url=jdbc:mysql://localhost:3306/medical_db
   db.user=your_username
   db.password=your_password
   

2. *OpenCV Paths*  
   Update in ImageProcessor.java:
   ```java
   static {
       System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
       // Or specify full path
       // System.load("/path/to/libopencv_java455.so");
   }
---

## 📜 License
Distributed under the MIT License. See LICENSE for details.

---
## 📧 Contact
Your Name - deshmukhg2004@gmail.com  
Project Link: "C:\Users\hp\OneDrive\Desktop\MedicalProject_gayatri.zip"
---
 





