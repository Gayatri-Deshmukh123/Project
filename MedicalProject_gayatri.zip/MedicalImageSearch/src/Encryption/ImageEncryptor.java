package Encryption;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.util.Base64;


public class ImageEncryptor {


	private static SecretKey secretKey;
	
	 static {
	        try {
	            // Generate a secret key for AES encryption
	            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
	            keyGen.init(128); // 128-bit key
	            secretKey = keyGen.generateKey();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }

	 
	
	 public static byte[] encrypt(byte[] data) throws Exception
	 {
	        Cipher cipher = Cipher.getInstance("AES");
	        cipher.init(Cipher.ENCRYPT_MODE, secretKey);
	        return cipher.doFinal(data);
	  }
	 
	 public static byte[] decrypt(byte[] data) throws Exception
	 {
		 Cipher cipher = Cipher.getInstance("AES");
		 cipher.init(Cipher.DECRYPT_MODE, secretKey);
		 return cipher.doFinal(data);
		 
		 
	 }


	
	
}