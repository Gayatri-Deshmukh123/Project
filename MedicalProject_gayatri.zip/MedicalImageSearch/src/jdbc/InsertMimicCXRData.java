package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

//add encryption and decryption
import javax.crypto.Cipher;

public class InsertMimicCXRData {
	private static final String URL = "jdbc:mysql://localhost:3306/medical_db";
    private static final String USER = "root";
    private static final String PASSWORD = "Jdbc@2025";
    

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	 // Data from the file
		String[][] data = {
				 {"1000116673", "P001", "S001", "../input/c/1000116603.jpg", "EAI | aS as tube hi ../input/c)", "Extra Field 1"},
				    {"1000116674", "P002", "S002", "../input/c/1000116604.jpg", "Example text for image 2", "Extra Field 2"},
				    {"1000116675", "P003", "S003", "../input/c/1000116605.jpg", "Example text for image 3", "Extra Field 3"},
				    {"1000116676", "P004", "S004", "../input/c/1000116606.jpg", "Example text for image 4", "Extra Field 4"},
				    {"1000116677", "P005", "S005", "../input/c/1000116607.jpg", "Example text for image 5", "Extra Field 5"},
				    {"1000116678", "P006", "S006", "../input/c/1000116608.jpg", "Example text for image 6", "Extra Field 6"}

	        };


     // Insert data
        String query = "INSERT INTO mimic_cxr_images (id, patient_id, study_id, image_path,encrypted_data, text) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {
        	

        	  for (String[] row : data) {
        		  

                  stmt.setString(1, row[0]); // ID
                  stmt.setString(2, row[1]); // Patient ID
                  stmt.setString(3, row[2]); // Study ID
                  stmt.setString(4, row[3]); // Image Path
                  stmt.setString(5, row[4]); //encrypted data
                  stmt.setString(6, row[5]); // Text
                  int rowsInserted = stmt.executeUpdate();
                  System.out.println("Inserted: " + rowsInserted + " row(s) for ID " + row[0]);
              }
        } catch (Exception e) {
            e.printStackTrace();

	}

}

}
