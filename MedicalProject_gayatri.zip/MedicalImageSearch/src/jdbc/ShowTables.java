package jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ShowTables {

	private static final String URL = "jdbc:mysql://localhost:3306/medical_db";
    private static final String USER = "root";
    private static final String PASSWORD = "Jdbc@2025";
    

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
	             Statement stmt = conn.createStatement()) {
          
			//show tables
			 ResultSet rs = stmt.executeQuery("SHOW TABLES");
	            System.out.println("Tables in the database:");
	            while (rs.next()) {
	                System.out.println(rs.getString(1));
	            }
	            rs = stmt.executeQuery("DESCRIBE medical_images");
	            System.out.println("\nStructure of medical_images table:");
	            while (rs.next()) {
	                System.out.println(
	                    rs.getString("Field") + "\t" +
	                    rs.getString("Type") + "\t" +
	                    rs.getString("Null") + "\t" +
	                    rs.getString("Key") + "\t" +
	                    rs.getString("Default") + "\t" +
	                    rs.getString("Extra")
	                );
	            }
	        } catch (Exception e)
		{
	        	e.printStackTrace();
		}
	 }



}
