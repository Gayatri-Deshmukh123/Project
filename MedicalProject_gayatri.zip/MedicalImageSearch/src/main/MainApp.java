package main;

import java.util.Base64;

import Encryption.ImageEncryptor;

public class MainApp
{
	


	public static void main(String[] args)
	{
		try
		{
			//Simulate image data
			byte[] imageData = "Simulated image data".getBytes();
			
			//Encrypt the image 
			byte[] encryptedData = ImageEncryptor.encrypt(imageData);
			
			//Decrypt the image
			byte[] decryptedData = ImageEncryptor.decrypt(encryptedData);
			
			//print result
			System.out.println("Original:" + new String(imageData));
			System.out.println("Encrypted:" + Base64.getEncoder().encodeToString(encryptedData));
			System.out.println("Decrypted: " + new String(decryptedData));

		}
		catch(Exception e)
		{
			
		}
		 

	}
}