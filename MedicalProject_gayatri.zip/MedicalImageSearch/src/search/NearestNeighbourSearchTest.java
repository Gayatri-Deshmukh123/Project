package search;

import org.junit.Test;
import static org.junit.Assert.*;

public class NearestNeighbourSearchTest{
	 @Test
	    public void testEuclideanDistance() {
	        // Test case 1
	        double[] a = {1.0, 2.0, 3.0};
	        double[] b = {4.0, 5.0, 6.0};
	        double expectedDistance = 5.196; // sqrt((4-1)^2 + (5-2)^2 + (6-3)^2)
	        double actualDistance = NearestNeighbourSearch.euclideanDistance(a, b);
	        assertEquals(expectedDistance, actualDistance, 0.001);

	        // Test case 2
	        double[] c = {0.0, 0.0, 0.0};
	        double[] d = {0.0, 0.0, 0.0};
	        assertEquals(0.0, NearestNeighbourSearch.euclideanDistance(c, d), 0.001);
	    }
	 
	 @Test
     public void testLowerBoundDistance() {
     	//Test case 1
     	  double[] query = {1.0, 2.0, 3.0};
           double[] candidate = {4.0, 5.0, 6.0};
           double[] std = {1.0, 1.0, 1.0};
           double expectedLowerBound = 3.464; // sqrt((|4-1|-1)^2 + (|5-2|-1)^2 + (|6-3|-1)^2)
           double actualLowerBound = NearestNeighbourSearch. lowerBoundDistance(query, candidate, std);
           assertEquals(expectedLowerBound,actualLowerBound,0.001);
     }

       @Test
       public void testFindNearestNeighbour() {
    	   //Test dataset
    	   double[][] dataset = {
    	            {1.2, 2.3, 3.4},
    	            {4.5, 5.6, 6.7},
    	            {7.8, 8.9, 9.0}
    	        };
          //Test query
    	   double[] query = {1.0, 2.0, 3.0};
           double[] std = {1.0, 1.0, 1.0};

           // Expected nearest neighbor index
           int expectedIndex = 0;

           //find the nearest neighbour 
          int actualIndex = NearestNeighbourSearch.findNearestNeighbor(dataset, query,std);
       }
        
       }


   
