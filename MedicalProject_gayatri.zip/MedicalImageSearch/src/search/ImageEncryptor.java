package search;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class ImageEncryptor {
	private static final String SECRET_KEY = "ThisIsASecretKey"; // 16-character secret key for AES
	private static final String INIT_VECTOR = "RandomInitVector";
    //private static final String ALGORITHM = "AES";
    private static final String ALGORITHM = "AES/CBC/PKCS5Padding"; // Use CBC mode with PKCS5 padding

    // Encrypt a feature vector
    public double[] encrypt(double[] dataset) {


    	try {
            // Convert the double array to a string
            String dataString = arrayToString(dataset);

            // Encrypt the string
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            SecretKeySpec secretKey = new SecretKeySpec(SECRET_KEY.getBytes(StandardCharsets.UTF_8), "AES");
            IvParameterSpec iv = new IvParameterSpec(INIT_VECTOR.getBytes(StandardCharsets.UTF_8));
            cipher.init(Cipher.ENCRYPT_MODE, secretKey,iv);
            byte[] encryptedBytes = cipher.doFinal(dataString.getBytes(StandardCharsets.UTF_8));//encrypt the string

            // Convert the encrypted bytes to a double array
            return bytesToDoubleArray(encryptedBytes);
        } catch (Exception e) {
            throw new RuntimeException("Encryption failed", e);
        }
    	
    }
 // Decrypt a feature vector
    public double[] decrypt(double[] encryptedData) {
        try {
            // Convert the double array to bytes
            byte[] encryptedBytes = doubleArrayToBytes(encryptedData);

            // Decrypt the bytes
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            SecretKeySpec secretKey = new SecretKeySpec(SECRET_KEY.getBytes(StandardCharsets.UTF_8), "AES");
            IvParameterSpec iv = new IvParameterSpec(INIT_VECTOR.getBytes(StandardCharsets.UTF_8));
            cipher.init(Cipher.DECRYPT_MODE, secretKey,iv);
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);

            // Convert the decrypted bytes to a double array
            String decryptedString = new String(decryptedBytes, StandardCharsets.UTF_8);
            return stringToArray(decryptedString);
        } catch (Exception e) {
            throw new RuntimeException("Decryption failed", e);
        }
    }
    // Helper method to convert a double array to a string
    private String arrayToString(double[] data) {
        StringBuilder sb = new StringBuilder();
        for (double d : data) {
            sb.append(d).append(",");
        }
        return sb.toString();
    }
    // Helper method to convert a string to a double array
    private double[] stringToArray(String data) {
        String[] parts = data.split(",");
        double[] array = new double[parts.length];
        for (int i = 0; i < parts.length; i++) {
            array[i] = Double.parseDouble(parts[i]);
        }
        return array;
    }
    // Helper method to convert bytes to a double array
    private double[] bytesToDoubleArray(byte[] bytes) {
        double[] array = new double[bytes.length];  // Double.BYTES];
        for (int i = 0; i < bytes.length; i++) {
            array[i] = bytes[i];
        }
        return array;
    }

    //Helper method to convert a double array to bytes
    private byte[] doubleArrayToBytes(double[] array) {
    	byte[] bytes = new byte[array.length]; //*Double.BYTES];
    	for(int i=0; i<array.length; i++) {
    		bytes[i] = (byte) array[i];
    	}
    	return bytes;
    }
    //main method to test the class
    public static void main(String[] args) {
    	//Example feature vector
    	double[] featureVector = {1.2, 2.3, 3.4};
    	//initialize image encryptor
    	ImageEncryptor imageEncryptor = new ImageEncryptor();
    	//encrypt the feature vector
    	double[] encryptedVector = imageEncryptor.encrypt(featureVector);
    	System.out.println("Encrypted Vector: " + java.util.Arrays.toString(encryptedVector));
    	//Decrypt the feature vector
    	double[] decryptedVector = imageEncryptor.decrypt(encryptedVector);
    	System.out.println("Decrypted Vector: " + java.util.Arrays.toString(decryptedVector));
    }
   
}
