package search;

import org.junit.Test;
import static org.junit.Assert.*;

public class MainAppIntegrationTest {
	@Test
    public void testMainAppLogic() {
        // Initialize ImageEncryptor
        ImageEncryptor imageEncryptor = new ImageEncryptor();

        // Sample dataset
        double[][] dataset = {
            {1.0, 2.0},
            {3.0, 4.0},
            {5.0, 6.0}
            
        };
        
       //Encrypt the dataset
        double[][] encryptedDataset = MainApp.encryptdataset(dataset, imageEncryptor);
        assertNotNull("Encrypted dataset should not be null", encryptedDataset);
        assertEquals("Encrypted dataset should have the same number of rows as the original dataset", dataset.length, encryptedDataset.length);
        assertEquals("Encrypted dataset should have the same number of columns as the original dataset", dataset[0].length, encryptedDataset[0].length);

        
        // Encrypt the query
        double[] query = {1.0, 2.0};
        double[] encryptedQuery = imageEncryptor.encrypt(query);
        assertNotNull("Encrypted query should not be null", encryptedQuery);
        assertEquals("Encrypted query should have the same length as the original query", query.length, encryptedQuery.length);
        
        // Compute the standard deviation of the dataset
        double stdDev = NearestNeighbourSearch.computeStandardDeviation(encryptedDataset); 
        assertTrue("Standard Deviation should be a positive value", stdDev >= 0);
        
        // Find the nearest neighbor
        double[] stdDevArray = {stdDev};
        int nearestIndex = NearestNeighbourSearch.findNearestNeighbor(encryptedDataset, encryptedQuery, stdDevArray);
        double[] nearestEncryptedVector = encryptedDataset[nearestIndex];
        assertTrue("Nearest index should be valid", nearestIndex >= 0 && nearestIndex < encryptedDataset.length);

        //decrypt the nearest neighbour
        double[] nearestDecryptedVector = imageEncryptor.decrypt(nearestEncryptedVector);
        //verify the results
        assertEquals(0,nearestIndex);
        assertArrayEquals(query,nearestDecryptedVector,0.0001);
       
       //System.out.println("Original dataset dimensions: " + dataset.length + "x" + dataset[0].length);
       //System.out.println("Encrypted dataset dimensions: " + encryptedDataset.length + "x" + encryptedDataset[0].length);


      
	}

}
