package search;

public class NearestNeighbourSearch 
{
	 public static  double computeStandardDeviation(double[][] data) {
	        double sum = 0, mean, standardDeviation = 0;
	        int n = data.length * data[0].length; // Total number of elements

	        // Compute the mean
	        for (double[] row : data) {
	            for (double value : row) {
	                sum += value;
	            }
	        }
	        mean = sum / n;

	        // Compute variance
	        for(double[] row:data) {
	        	for(double value:row) {
	        		standardDeviation += Math.pow(value-mean, 2);
	        	}
	        }
	        return Math.sqrt(standardDeviation/n);
	}
	 public static double euclideanDistance(double[] a, double[] b)
	 {
	        double sum = 0;
	        for (int i = 0; i < a.length; i++)
	        {
	            sum += Math.pow(a[i] - b[i], 2);
	        }
	        return Math.sqrt(sum);
	  }
	 
	 // Compute the lower bound of Euclidean distance
	    public static double lowerBoundDistance(double[] query, double[] candidate, double[] std) {
	       double sum = 0;
	       for (int i = 0; i < query.length; i++) {
	           double diff = Math.abs(query[i] - candidate[i]);
	           sum += Math.pow(diff - std[i], 2);
	        }
	       return Math.sqrt(sum);
	    }
	    /*
	 public static int findNearestNeighbor(double[][] dataset, double[] query)
	   {
	      int nearestIndex = -1;
	      double minDistance = Double.MAX_VALUE;

	       for (int i = 0; i < dataset.length; i++)
	     {
	           double distance = euclideanDistance(dataset[i], query);
	           if (distance < minDistance) {
	              minDistance = distance;
	               nearestIndex = i;
	           }
	       }
	       return nearestIndex;
	}
	 
	 */
	// Find the nearest neighbor for a given query
	    public static  int findNearestNeighbor(double[][] dataset, double[] query, double[] std) {
	        int nearestIndex = -1;
	        double minDistance = Double.MAX_VALUE;

	        for (int i = 0; i < dataset.length; i++) {
	            // Compute the lower bound of Euclidean distance
	            double lbDistance = lowerBoundDistance(query, dataset[i], std);

	            // Skip if the lower bound is greater than the current minimum distance
	            if (lbDistance >= minDistance) {
	                continue;
	            }

	            // Compute the actual Euclidean distance
	            double distance = euclideanDistance(dataset[i], query);

	            //Update the nearest neighbor if this candidate is closer
	            if (distance < minDistance) {
	                minDistance = distance;
	                nearestIndex = i;
	            }
	        }

	        return nearestIndex;
	    }

/*
	 public static void main(String[] args) 
	 {
	 	// TODO Auto-generated method stub
		 double[][] dataset = {{1, 2}, {2, 3}, {3, 4}}; // Example dataset
	        double[] query = {1.5, 2.5}; // Example query
	        int nearestIndex = findNearestNeighbor(dataset, query);
	        System.out.println("Nearest neighbor index: " + nearestIndex);
*/
 
	    public static void main(String[] args) {
	    	// Example dataset of feature vectors
	          double[][] dataset = {
	        		  {1.2,2.3,3.4},
	        		  {4.5,5.6,6.7},
	        		  {7.8,8.9,9.0},
	        		  {0.5,1.0,1.5}
	          };
	       // Compute the standard deviation of the dataset
	          double[] std = {1.0, 1.0, 1.0}; // Replace with actual computation
	          
	          // Query feature vector
	          double[] query = {1.0, 2.0, 3.0};

	       // Find the nearest neighbor
	          int nearestIndex = findNearestNeighbor(dataset, query, std);
	          double[] nearestVector = dataset[nearestIndex];

	          // Output the result
	          System.out.println("Query: " + java.util.Arrays.toString(query));
	          System.out.println("Nearest Neighbor Index: " + nearestIndex);
	          System.out.println("Nearest Neighbor Vector: " + java.util.Arrays.toString(nearestVector));



	 }
	

	
}


