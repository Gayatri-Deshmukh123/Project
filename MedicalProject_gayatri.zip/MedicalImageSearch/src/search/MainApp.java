package search;
import java.util.Base64;

import Encryption.ImageEncryptor;


public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try
		{
			//Simulate image data
			byte[] imageData = "Simulated image data".getBytes();
			
			//Encrypt the image 
			byte[] encryptedData = ImageEncryptor.encrypt(imageData);
			
			//Decrypt the image
			byte[] decryptedData = ImageEncryptor.decrypt(encryptedData);
			
			//print result
			System.out.println("Original:" + new String(imageData));
			System.out.println("Encrypted:" + Base64.getEncoder().encodeToString(encryptedData));
			System.out.println("Decrypted: " + new String(decryptedData));

		}
		catch(Exception e)
		{
			
		}

	}

	public static double[][] encryptdataset(double[][] dataset, search.ImageEncryptor imageEncryptor) {
		// TODO Auto-generated method stub
		 if (dataset == null || imageEncryptor == null) {
	          throw new IllegalArgumentException("Dataset or ImageEncryptor cannot be null");
	       }

	        double[][] encryptedDataset = new double[dataset.length][];
	        for (int i = 0; i < dataset.length; i++) {
	            encryptedDataset[i] = imageEncryptor.encrypt(dataset[i]);
	            // Print the number of columns before and after encryption
	            System.out.println("Original row " + i + " length: " + dataset[i].length);
	            System.out.println("Encrypted row " + i + " length: " + encryptedDataset.length);

	            // Check if encryption changed the size
	           if (encryptedDataset.length != dataset[i].length) {
	              throw new RuntimeException("Encryption changed column count! Expected: " 
	                   + dataset[i].length + ", but got: " + encryptedDataset.length);
	           }

	            encryptedDataset[i] = dataset[i];
	        }

	        

		return encryptedDataset;
	}

}
