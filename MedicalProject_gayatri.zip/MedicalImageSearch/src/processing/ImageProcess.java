package processing;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.*;



public class ImageProcess {
    // Corrected feature vector array syntax
    public static double[] imageToFeatureVector(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();
        double[] featureVector = new double[width * height];

        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                // Corrected pixel retrieval
                int pixel = image.getRaster().getSample(x, y, 0);
                // Fixed array index syntax
                featureVector[y * width + x] = pixel / 255.0;
            }
        }
        return featureVector;
    }
    public static void main(String[] args) {
    	 SwingUtilities.invokeLater(() -> {
             try {
                 // 1. Load medical image
                 File imageFile = new File("C:/Users/hp/OneDrive/Pictures/chestxrayimg.jpg");
                 verifyFileExists(imageFile);

                 // 2. Process image
                 BufferedImage original = ImageIO.read(imageFile);
                 BufferedImage grayscale = convertToGrayscale(original);
                 BufferedImage resized = resizeImage(grayscale, 256, 256);

                 // 3. Display results
                 displayImage(original, "Original Image");
                 displayImage(grayscale, "Grayscale Image");
                 displayImage(resized, "Resized Image (256x256)");

             } catch (IOException | ImageProcessingException e) {
                 System.err.println("Error processing image: " + e.getMessage());
             }
         });
    }
    private static void verifyFileExists(File file) throws ImageProcessingException {
        if (!file.exists()) {
            throw new ImageProcessingException(
                "Image file not found at: " + file.getAbsolutePath()
            );
        }
    }

    private static BufferedImage convertToGrayscale(BufferedImage colorImage) {
        BufferedImage grayscale = new BufferedImage(
            colorImage.getWidth(),
            colorImage.getHeight(),
            BufferedImage.TYPE_BYTE_GRAY
        );
        
        Graphics2D g2d = grayscale.createGraphics();
        g2d.drawImage(colorImage, 0, 0, null);
        g2d.dispose();
        
        return grayscale;
    }
    private static BufferedImage resizeImage(BufferedImage original, int newWidth, int newHeight) {
        Image scaled = original.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
        
        BufferedImage resized = new BufferedImage(
            newWidth, 
            newHeight, 
            BufferedImage.TYPE_INT_ARGB
        );
        
        Graphics2D g2d = resized.createGraphics();
        g2d.drawImage(scaled, 0, 0, null);
        g2d.dispose();
        
        return resized;
    }


            // 1. Correct resource path (using forward slashes)
        	/*
            String imagePath = "C:/Users/hp/OneDrive/Pictures/chestxrayimg.jpg";
            File file = new File(imagePath);
            
            // Verify resource exists
            if (!file.exists()) {
                System.err.println("Image file not found!");
           
                return;
            }

            // 2. Correct image reading (using BufferedImage)
            BufferedImage originalImage = ImageIO.read(file);
            
            // 3. Convert to grayscale (ensure method exists)
            BufferedImage grayscaleImage = convertToGrayscale(originalImage);
            
            // 4. Resize with valid dimensions (28x28 instead of 2B)
            BufferedImage resizedImage = resizeImage(grayscaleImage, 28, 28);
            
            // 5. Extract feature vector
            double[] featureVector = imageToFeatureVector(resizedImage);

        }catch(IOException e) {
        	e.printStackTrace();
        }
        */
    
    
 // Display image in a window
    private static void displayImage(BufferedImage image, String title) {
        JFrame frame = new JFrame(title);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        int scaleFactor = (image.getWidth() <= 28) ? 10 : 1;
        Image scaledImage = image.getScaledInstance(
        		image.getWidth()*scaleFactor,
        		image.getHeight()*scaleFactor, 
        	    Image.SCALE_SMOOTH);
        
        JLabel label = new JLabel(new ImageIcon(image));
        frame.add(label);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
    static class ImageProcessingException extends Exception{
    	public ImageProcessingException(String message) {
    		super(message);
    	}
    }

/*
 // Add these required methods
    private static BufferedImage convertToGrayscale(BufferedImage image) {
        BufferedImage grayscale = new BufferedImage(
            image.getWidth(), image.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
        grayscale.getGraphics().drawImage(image, 0, 0, null);
        return grayscale;
    }

    private static BufferedImage resizeImage(BufferedImage image, int width, int height) {
        Image tmp = image.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        BufferedImage resized = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        resized.getGraphics().drawImage(tmp, 0, 0, null);
        return resized;

}
*/
}
    