package processing;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.Properties;
import java.util.regex.Pattern;



public class MedicalAuthSystem {
	private static final String URL = "jdbc:mysql://localhost:3306/medical_db";
    private static final String USER = "root";
    private static final String PASSWORD = "Jdbc@2025";
	private static final String USER_FILE = "users.properties";
    private static Properties users = new Properties();
    private static final Pattern PHONE_PATTERN = Pattern.compile("\\d{10}");
    private static final Pattern PIN_PATTERN = Pattern.compile("\\d{4}");

    public static void showRegistration() {
        JFrame frame = new JFrame("Patient Registration");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        centerFrame(frame);

        JPanel panel = new JPanel(new GridLayout(8, 2, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JTextField txtUsername = new JTextField();
        JPasswordField txtPassword = new JPasswordField();
        JTextField txtName = new JTextField();
        JTextField txtAddress = new JTextField();
        JTextField txtPhone = new JTextField();
        JPasswordField txtPin = new JPasswordField();

        JButton btnRegister = new JButton("Register");
        JButton btnCancel = new JButton("Cancel");

        // Add components to panel
        panel.add(new JLabel("Username*:"));
        panel.add(txtUsername);
        panel.add(new JLabel("Password*:"));
        panel.add(txtPassword);
        panel.add(new JLabel("Full Name*:"));
        panel.add(txtName);
        panel.add(new JLabel("Address*:"));
        panel.add(txtAddress);
        panel.add(new JLabel("Phone No*:"));
        panel.add(txtPhone);
        panel.add(new JLabel("4-digit PIN*:"));
        panel.add(txtPin);
        panel.add(btnRegister);
        panel.add(btnCancel);

        loadUsers(); // Load existing users

        btnRegister.addActionListener(e -> {
            try {
                String username = txtUsername.getText().trim();
                String password = new String(txtPassword.getPassword());
                String name = txtName.getText().trim();
                String address = txtAddress.getText().trim();
                String phone = txtPhone.getText().trim();
                String pin = new String(txtPin.getPassword());

                if (validateInputs(username, password, name, address, phone, pin)) {
                    String userData = String.join(";", 
                        password, name, address, phone, pin);
                    
                    users.setProperty(username, userData);
                    saveUsers();
                    JOptionPane.showMessageDialog(frame,
                        "Registration Successful!\nPlease login with your credentials.","Success", JOptionPane.INFORMATION_MESSAGE);
                    frame.dispose();
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame,
                    "Error during registration: " + ex.getMessage(),
                    "Registration Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnCancel.addActionListener(e -> frame.dispose());

        frame.add(panel);
        frame.setVisible(true);
    }
    private static void registerUser(String username, String password, String name, String address, String phone, String pin) {
            String sql = "INSERT INTO users (username, password, name, address, phone, pin) " +"VALUES (?, ?, ?, ?, ?, ?)";

            try (Connection conn = DriverManager.getConnection(URL,USER,PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement(sql)) {

// Set parameters
pstmt.setString(1, username);
pstmt.setString(2, password); // In production, hash the password
pstmt.setString(3, name);
pstmt.setString(4, address);
pstmt.setString(5, phone);
pstmt.setString(6, pin);

int affectedRows = pstmt.executeUpdate();
if (affectedRows > 0) {
JOptionPane.showMessageDialog(null, 
"Registration successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
}
} catch (SQLException ex) {
    if (ex.getErrorCode() == 1062) { // Duplicate entry
JOptionPane.showMessageDialog(null, "Username already exists!", "Error",JOptionPane.ERROR_MESSAGE);
} else {
    JOptionPane.showMessageDialog(null, 
        "Registration failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
}
}
}
 

    private static boolean validateInputs(String username, String password, 
                                       String name, String address, 
                                       String phone, String pin) {
        if (username.isEmpty() || password.isEmpty() || name.isEmpty() ||
            address.isEmpty() || phone.isEmpty() || pin.isEmpty()) {
            showError("All fields marked with (*) are required!");
            return false;
        }

        if (users.containsKey(username)) {
            showError("Username already exists!");
            return false;
        }
        if (!PHONE_PATTERN.matcher(phone).matches()) {
            showError("Invalid phone number! Must be 10 digits.");
            return false;
        }

        if (!PIN_PATTERN.matcher(pin).matches()) {
            showError("Invalid PIN! Must be 4 digits.");
            return false;
        }

        if (password.length() < 8) {
            showError("Password must be at least 8 characters!");
            return false;
        }

        return true;
    }

    private static void loadUsers() {
        try (InputStream input = new FileInputStream(USER_FILE)) {
            users.load(input);
        } catch (IOException e) {
            // File will be created on first registration
        }
    }
    private static void saveUsers() {
        try (OutputStream output = new FileOutputStream(USER_FILE)) {
            users.store(output, "Medical Patient Registry");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null,
                "Failed to save user data!", "Storage Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static void centerFrame(Window frame) {
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(
            (screenSize.width - frame.getWidth()) / 2,
            (screenSize.height - frame.getHeight()) / 2
        );
    }

    private static void showError(String message) {
        JOptionPane.showMessageDialog(null,
            message, "Input Error", JOptionPane.ERROR_MESSAGE);
    }

  


    public static void main(String[] args) {
        loadUsers();
        showRegistration();
    }
    private static boolean isUsernameExists(String username) {
    String sql = "SELECT username FROM users WHERE username = ?";
    try(Connection conn = DriverManager.getConnection(URL,USER,PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement(sql)){
    	       pstmt.setString(1,username);
    	       try(ResultSet rs = pstmt.executeQuery()){
    	    	   return rs.next();
    	       }
            }catch(SQLException e) {
            	e.printStackTrace();
            	return true;
            }
    }
}
    
